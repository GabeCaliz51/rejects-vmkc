# RVMKK — Recent game-only update staging (2026-11-18)

## Purpose and safety
Verified export from the **November 2026 three-fighter import**, preserved for integration into the RVMKK rebuild inside the Rejects Universe site project. This is **not** a deployable replacement website. It is not a rendering of unapproved recent Kardozo illustrations or videos.

The *existing* `rejects-vmkc` GitHub repository contains an independent early prototype, while the current 10-fighter RVMKK implementation lives in the Rejects Universe site worktree. Do not overwrite the prototype or the newer local website files with this package without a path-by-path diff against the actual current worktree. No website or game deployment is authorized by this staging operation.

## Source files included
The `site-patches/` directory contains all 22 exported files from `Update-RVMKK-Import-Three-Fighters.ps1`:
- 14 RVMKK React/JS/CSS source files (including imported fighter logic and combat engine integration).
- 8 WebP fighter art assets for Nicoleena, Cokane-O and Scorpurtis.
Every file was decoded and independently SHA-256 verified against the importer's original `after` hash. Inspect `MANIFEST-SHA256.txt` for path and SHA-256.

## Established and approved
- Ten playable fighters: GAIBDEN, GARE-CHI, DA’TENNISHA BLAZE, TREYTARO, KITARIA, KEEN-KAHN, KARDOZO, NICOLEENA, COKANE-O, SCORPURTIS; **X-MAN is final boss**, not playable roster slot.
- Old Rape-O name superseded by **COKANE-O**. Do not add another DA’STONYA roster slot.
- Kardozo: exactly four connected arms; approved base visual art preserved. The recently rejected stills and crude animation renders are **not** accepted assets.
- Nicoleena: longer, thinner, durable tongue with forward spiral/slinky action as approved design requirement; don't claim an unverified animation already works.
- Gaibden's special: **BAD CONNECTION**; finishing move: **LOW BATTERY**.
- X-MAN calls out **KEYZER SÖZE!** to his accompanying dogs; it is *not* a separate fighter or X-MAN's own name.

## Newer combat fixes requested — require implementation + game verification
1. **Body continuity**: body parts cannot become detached or offset while moving, jumping, falling, turning or lying horizontally after knockdown (not just the head). Separation only where explicitly intended as a special effect.
2. **Fighter visibility**: during normal close-range combat the sprites may approach but must not cloak/cover one another. Both players should remain visible unless a specified special move intentionally overlaps them. Verify draw order, sprite bounds, anchor/scale, and physical separation together.
3. The full Kardozo overhead slam retains a continuous ankle grab, coherent four-arm anatomy, natural opponent ragdoll/flailing, head/eye tracking, aggressive ground impacts. The math-only studies and rejected MP4s are **not visual approval**; do not promote them to finished gameplay.

## Incomplete / intentionally not represented as done
- Game visually tested in browser / phone, complete Kardozo animation, separately corrected limb rig, punch/slam artwork.
- Finished combat overhaul (#4) for the six core characters; Gaibden first, Kardozo explicitly skipped in the previously authorized pass.
- Character-specific gag and finishing animation routines not verified against the latest site.

## Install guidance
Compare each `site-patches/<relative-path>` with the corresponding actual worktree file, hash all target files, and integrate approved differences **without overwriting newer corrections**. Preserve backups. This staging export does **not** run an installer, create a website build, or trigger Vercel.
