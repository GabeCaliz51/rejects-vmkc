'use client';
import GameImage from './GameImage.jsx';
import {useEffect,useRef,useState} from 'react';
import {SELECT_THEMES,SELECTION_HEIGHT,CHARGES,ENTRANCE_LINES} from './SelectionThemes.mjs';
import styles from './SelectionStage.module.css';
const ROOT='/assets/rvmkk-rebuild';
// Each emote uses the existing transparent personality frames rather than moving a flat menu screenshot.
const FRAMES={gaibden:[6,11,6],kitaria:[1,4,1],treytaro:[0,1,0],kardozo:[0,1,0],'datennisha-blaze':[1,4,1],'gare-chi':[0,9,0]};
function Actor({fighter,active=false,beat=0,role='guest'}){
 const seq=FRAMES[fighter.id]??[0];
 const frame=active?seq[Math.min(beat,seq.length-1)]:seq[0];
 const src=fighter.imported?fighter.art:['keen-kahn','kardozo'].includes(fighter.id)?`${ROOT}/selection/${fighter.id}.webp`:`${ROOT}/combat/personality/${fighter.id}-frames/${String(frame).padStart(2,'0')}.webp`;
 return <div className={`${styles.actor} ${active?styles.highlight:''}`} data-character={fighter.id} data-role={role} style={{'--height':SELECTION_HEIGHT[fighter.id]??.9}}>
   <GameImage src={src} fallbackSrc={fighter.imported?undefined:`${ROOT}/combat/personality/${fighter.id}-frames/00.webp`} alt={fighter.name} draggable={false}/>
 </div>;
}
export default function SelectionStage({themeId,fighters,focused,playerOne,activePlayer}){
 const [beat,setBeat]=useState(0),[revealed,setRevealed]=useState(false),[old,setOld]=useState(null);
 const previous=useRef(focused);
 const theme=SELECT_THEMES.find(t=>t.id===themeId)??SELECT_THEMES[0];
 useEffect(()=>{
   setOld(previous.current.id!==focused.id?previous.current:null);previous.current=focused;
   setBeat(0);setRevealed(false);
   const timers=[setTimeout(()=>setRevealed(true),90),setTimeout(()=>setBeat(1),550),setTimeout(()=>setBeat(2),1200),setTimeout(()=>setOld(null),650)];
   return()=>timers.forEach(clearTimeout);
 },[focused.id,themeId]);
 const left=activePlayer===0?focused:playerOne;
 const right=activePlayer===1?focused:null;
 return <div className={styles.stage} data-theme={theme.id} data-revealed={revealed} aria-label={`${theme.title}, ${focused.name} highlighted`}>
   <GameImage className={styles.backdrop} src={`${ROOT}/selection/${theme.id}.webp`} alt=""/>
   <div className={styles.vignette}/>
   {theme.id==='lineup'?<div className={styles.lineup} style={{'--roster-count':fighters.length}}>
     {fighters.map(f=><div key={f.id} className={styles.suspect} data-active={f.id===focused.id}>
       <Actor fighter={f} active={f.id===focused.id} beat={beat}/><span className={styles.charge}>{CHARGES[f.id]??f.name}</span>
     </div>)}
   </div>:theme.id==='party'?<>
     <div className={styles.guests}>{fighters.filter(f=>f.id!==focused.id).map(f=><Actor key={f.id} fighter={f}/>)}</div>
     {old&&<div key={`exit-${old.id}`} className={styles.ejected}><Actor fighter={old}/><span>MOVE, MOTHERFUCKER.</span></div>}
     <div key={focused.id} className={styles.entrance} data-character={focused.id}><Actor fighter={focused} active beat={beat} role="selected"/></div>
     <div key={`doors-${focused.id}`} className={styles.partyDoors} aria-hidden="true"><i/><i/></div>
     <p className={styles.partySign}>NO +1s. ESPECIALLY YOU.</p>
     <p key={`line-${focused.id}`} className={styles.entranceLine}>{ENTRANCE_LINES[focused.id]??focused.name}<small>… awkward silence … *cough*</small></p>
   </>:<div className={styles.duel}>
     {[left,right].map((f,i)=><div className={styles.slot} key={i} data-side={i}>
       <div className={styles.actorSpace}>{f?<Actor key={`${f.id}-${theme.id}`} fighter={f} active={i===activePlayer} beat={beat} role="selected"/>:<span className={styles.waiting}>P2<br/><small>YOUR TURN NEXT.</small></span>}</div>
       {theme.id==='elevators'&&<div key={`door-${focused.id}-${i}`} className={styles.liftDoors} data-open={!!f&&(i!==activePlayer||revealed)} aria-hidden="true"><i/><i/></div>}
       {theme.id==='weighin'&&<span className={styles.readout}>{f?'READY':'WAITING'}</span>}
       <strong className={styles.name}>{f?f.name:`PLAYER ${i+1}`}</strong>
     </div>)}
     {theme.id==='faceoff'&&<b className={styles.vs}>VS</b>}
   </div>}
 </div>;
}
