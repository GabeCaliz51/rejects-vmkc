// A continuous skin deformation keeps each fighter's own sprite intact while
// the head, spine and loose limbs lag independently behind the captured ankle.
const point=(x,y)=>({x,y});
const add=(a,b)=>point(a.x+b.x,a.y+b.y);
const sub=(a,b)=>point(a.x-b.x,a.y-b.y);
const rotate=(p,a)=>point(p.x*Math.cos(a)-p.y*Math.sin(a),p.x*Math.sin(a)+p.y*Math.cos(a));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const distance=(p,a,b)=>{
 const dx=b.x-a.x,dy=b.y-a.y;
 const t=clamp(((p.x-a.x)*dx+(p.y-a.y)*dy)/(dx*dx+dy*dy||1),0,1);
 return (p.x-a.x-t*dx)**2+(p.y-a.y-t*dy)**2;
};
export function createSlamRagdoll(height,width,{time=0,amount=0,bend=0,whip=0,shock=0,ankle=.5}={}){
 const ratio=width/height,source=(u,q)=>point((u-ankle)*ratio,q-1);
 const heldLeft=ankle<=.5;
 const free=heldLeft?1:-1;
 const original={
  grip:source(ankle,1),heldKnee:source(heldLeft?.30:.70,.76),hip:source(.5,.53),
  freeKnee:source(heldLeft?.72:.28,.76),freeFoot:source(heldLeft?.79:.21,.98),
  chest:source(.5,.30),neck:source(.5,.18),head:source(.5,.065),
  leftShoulder:source(.30,.23),leftElbow:source(.13,.32),leftHand:source(.17,.40),
  rightShoulder:source(.70,.23),rightElbow:source(.87,.32),rightHand:source(.83,.40),
 };
 const target={grip:point(0,0)};
 const wave=(frequency,lag=0)=>Math.sin(time*frequency-lag);
 const heldFold=amount*(.20*wave(9,.4)+shock*.10);
 target.heldKnee=rotate(original.heldKnee,heldFold*.45);
 target.hip=add(target.heldKnee,rotate(sub(original.hip,original.heldKnee),heldFold));
 const spine=bend+amount*(.40*wave(8.5,.9)+.28*whip+shock*.45);
 target.chest=add(target.hip,rotate(sub(original.chest,original.hip),spine));
 target.neck=add(target.chest,rotate(sub(original.neck,original.chest),spine+amount*.24*wave(12,1.8)));
 target.head=add(target.neck,rotate(sub(original.head,original.neck),spine+amount*(.70*wave(11,2.2)+shock*.35)));
 const thigh=amount*(1.12*wave(8.6,1.2)+free*.35+whip*.45+shock*.4);
 const shin=thigh+amount*(1.48*wave(12.3,2.5)+shock*.6);
 target.freeKnee=add(target.hip,rotate(sub(original.freeKnee,original.hip),thigh));
 target.freeFoot=add(target.freeKnee,rotate(sub(original.freeFoot,original.freeKnee),shin));
 for(const [name,side,lag]of [['left',-1,.6],['right',1,2.1]]){
  const shoulder=name+'Shoulder',elbow=name+'Elbow',hand=name+'Hand';
  target[shoulder]=add(target.chest,rotate(sub(original[shoulder],original.chest),spine));
  const upper=spine+amount*(side*.5+.95*wave(10,lag)+.45*whip+shock*.35);
  const lower=upper+amount*(1.5*wave(13.5,lag+1.1)+shock*.6);
  target[elbow]=add(target[shoulder],rotate(sub(original[elbow],original[shoulder]),upper));
  target[hand]=add(target[elbow],rotate(sub(original[hand],original[elbow]),lower));
 }
 const pairs=[['grip','heldKnee'],['heldKnee','hip'],['hip','chest'],['chest','neck'],['neck','head'],
  ['hip','freeKnee'],['freeKnee','freeFoot'],['leftShoulder','leftElbow'],['leftElbow','leftHand'],
  ['rightShoulder','rightElbow'],['rightElbow','rightHand']];
 const bones=pairs.map(([a,b])=>{
  const from=sub(original[b],original[a]),to=sub(target[b],target[a]);
  const angle=Math.atan2(to.y,to.x)-Math.atan2(from.y,from.x);
  return {a:original[a],b:original[b],root:target[a],cos:Math.cos(angle),sin:Math.sin(angle),
   stretch:clamp(Math.hypot(to.x,to.y)/(Math.hypot(from.x,from.y)||1),.88,1.14)};
 });
 const raw=p=>{
  let x=0,y=0,total=0;
  for(const bone of bones){
   const weight=1/(.006+distance(p,bone.a,bone.b))**3;
   const dx=(p.x-bone.a.x)*bone.stretch,dy=(p.y-bone.a.y)*bone.stretch;
   x+=(bone.root.x+dx*bone.cos-dy*bone.sin)*weight;
   y+=(bone.root.y+dx*bone.sin+dy*bone.cos)*weight;total+=weight;
  }
  return point(x/total,y/total);
 };
 const anchor=raw(point(0,0));
 const rig={fit:1,joints:target,amount,
  project(u,q){const p=raw(source(u,q));return point((p.x-anchor.x)*height*rig.fit,(p.y-anchor.y)*height*rig.fit);}};
 return rig;
}
function triangle(ctx,image,source,destination){
 const [s0,s1,s2]=source,[d0,d1,d2]=destination;
 const sx1=s1.x-s0.x,sy1=s1.y-s0.y,sx2=s2.x-s0.x,sy2=s2.y-s0.y;
 const determinant=sx1*sy2-sx2*sy1;
 if(Math.abs(determinant)<1e-8)return;
 const dx1=d1.x-d0.x,dy1=d1.y-d0.y,dx2=d2.x-d0.x,dy2=d2.y-d0.y;
 const a=(dx1*sy2-dx2*sy1)/determinant,b=(dy1*sy2-dy2*sy1)/determinant;
 const c=(dx2*sx1-dx1*sx2)/determinant,d=(dy2*sx1-dy1*sx2)/determinant;
 ctx.save();ctx.beginPath();
 // A subpixel overlap hides raster seams between adjacent skin triangles.
 const center=point((d0.x+d1.x+d2.x)/3,(d0.y+d1.y+d2.y)/3);
 destination.forEach((v,index)=>{
  const length=Math.hypot(v.x-center.x,v.y-center.y)||1;
  const x=v.x+(v.x-center.x)/length*.35,y=v.y+(v.y-center.y)/length*.35;
  if(index)ctx.lineTo(x,y);else ctx.moveTo(x,y);
 });
 ctx.closePath();ctx.clip();
 ctx.transform(a,b,c,d,d0.x-a*s0.x-c*s0.y,d0.y-b*s0.x-d*s0.y);
 ctx.drawImage(image,0,0);ctx.restore();
}
export function drawSlamRagdoll(ctx,image,rig){
 const columns=14,rows=24,vertices=[];
 for(let row=0;row<=rows;row++)for(let col=0;col<=columns;col++){
  const u=col/columns,q=row/rows;
  vertices.push({source:point(u*image.width,q*image.height),destination:rig.project(u,q)});
 }
 for(let row=0;row<rows;row++)for(let col=0;col<columns;col++){
  const a=row*(columns+1)+col,b=a+1,c=a+columns+1,d=c+1;
  for(const indices of [[a,b,c],[b,d,c]])triangle(ctx,image,indices.map(i=>vertices[i].source),indices.map(i=>vertices[i].destination));
 }
}
