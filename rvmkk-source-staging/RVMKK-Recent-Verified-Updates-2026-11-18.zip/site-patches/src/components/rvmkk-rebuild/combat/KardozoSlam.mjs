import { fighterScale } from './FighterScale.mjs';
import { createSlamRagdoll, drawSlamRagdoll } from './SlamRagdoll.mjs';
// One clock drives both bodies, the ankle grip, damage and landing effects.
export const SLAM_TIMES=Object.freeze([1.65,2.47,3.2,4.08]);
export const SLAM_ACTION_END=5.15, SLAM_ACTIVE_SECONDS=4.6, SLAM_WORLD_SCALE=.00825;
const FLOOR=700;
const GRAB_END=.62,LIFT_END=1.16,IMPACT_HOLD=.10,FINAL_HOLD=.21;
const HOLD_END=SLAM_TIMES.at(-1)+FINAL_HOLD;
const LANDING_ANGLE=.09,DANGLE_ANGLE=1.33;
const C=t=>Math.max(0,Math.min(1,t));
const S=t=>{t=C(t);return t*t*(3-2*t);};
const mix=(a,b,t)=>a+(b-a)*t;
const p=(x,y)=>({x,y});
const lerp=(a,b,t)=>p(mix(a.x,b.x,t),mix(a.y,b.y,t));
export const slamTime=(elapsed,duration=SLAM_ACTIVE_SECONDS)=>C(elapsed/duration)*SLAM_ACTION_END;
export const slamOpponentHeight=id=>Math.max(280,Math.min(450,390*fighterScale(id)/.99));
export function twoBone(root,target,a,b,bend=1){
 const dx=target.x-root.x,dy=target.y-root.y,d=Math.max(.001,Math.hypot(dx,dy));
 const reach=Math.min(d,a+b-.001),c=Math.max(-1,Math.min(1,(a*a+reach*reach-b*b)/(2*a*reach)));
 const angle=Math.atan2(dy,dx)+bend*Math.acos(c);
 return {elbow:p(root.x+Math.cos(angle)*a,root.y+Math.sin(angle)*a),hand:target};
}
const rotate=(point,angle)=>p(point.x*Math.cos(angle)-point.y*Math.sin(angle),point.x*Math.sin(angle)+point.y*Math.cos(angle));
export function victimSegments(height,width,bend=0,ankle=.5){
 const offsetY=height*.06;
 const waist=p(width*(.5-ankle),-height*.45+offsetY);
 const neckOffset=rotate(p(0,-height*.38),bend);
 return [
  {from:.53,to:1,origin:p(0,offsetY),angle:0,x:-width*ankle,y:-height*.47,width,height:height*.47},
  {from:.16,to:.55,origin:waist,angle:bend,x:-width/2,y:-height*.39,width,height:height*.39},
  {from:0,to:.18,origin:p(waist.x+neckOffset.x,waist.y+neckOffset.y),angle:bend*.65,x:-width/2,y:-height*.18,width,height:height*.18},
 ];
}
export function victimBounds(segments,theta,outline,ragdoll){
 const points=[];
 const shape=outline??[{u:.36,q:0},{u:.64,q:0},{u:.3,q:.16},{u:.7,q:.16},{u:.02,q:.3},{u:.98,q:.3},{u:.22,q:.55},{u:.78,q:.55},{u:.18,q:.8},{u:.82,q:.8},{u:.1,q:1},{u:.9,q:1}];
 if(ragdoll){
  for(const v of shape)points.push(rotate(ragdoll.project(v.u,v.q),theta+Math.PI/2));
 }else for(const part of segments){
  for(const v of shape){
   if(v.q<part.from||v.q>part.to)continue;
   const x=part.x+v.u*part.width;
   const y=part.y+(v.q-part.from)*part.height/(part.to-part.from);
   const local=rotate(p(x,y),part.angle);
   points.push(rotate(p(local.x+part.origin.x,local.y+part.origin.y),theta+Math.PI/2));
  }
 }

 const contact=points.reduce((a,b)=>a.y>b.y?a:b);
 return {minX:Math.min(...points.map(v=>v.x)),maxX:Math.max(...points.map(v=>v.x)),minY:Math.min(...points.map(v=>v.y)),maxY:Math.max(...points.map(v=>v.y)),contact};
}
export function slamOptionsFor(winner,victim,cinematic=false){
 const opponentHeight=slamOpponentHeight(victim.definition.id);
 if(!cinematic)return {opponentHeight,startGrip:winner.slamStart};
 const side=(victim.x-winner.x)*winner.facing>=0?1:-1;
 return {opponentHeight,...(winner.slamFinisherStart??{startGrip:p(800+(victim.x-winner.x)*winner.facing/SLAM_WORLD_SCALE-side*opponentHeight/2,FLOOR-opponentHeight*.4),startAngle:side===1?0:-Math.PI})};
}
export function slamCameraFrame(initial,normal,focus,time,duration,aspect){
 const approach=S(time/.4),exit=S((time-duration+.4)/.4),height=Math.max(6.9,13.6/aspect);
 return {height:mix(mix(initial.height,height,approach),normal.height,exit),focusX:mix(mix(initial.focusX,focus,approach),normal.focusX,exit),focusY:mix(mix(initial.focusY,height*.28,approach),normal.focusY,exit)};
}
export function slamPose(time,{opponentHeight=390,startGrip=p(1000,FLOOR),startAngle=-Math.PI/2,opponentWidthRatio=.8,opponentOutline,ankle=.5}={}){
 opponentHeight=Math.min(opponentHeight,585/Math.hypot(1,opponentWidthRatio));
 const t=Math.max(0,Math.min(10,time));
 const liftY=FLOOR-opponentHeight*.64-98;
 let hips=p(800,500),grip=startGrip,theta=startAngle,lean=0,impact=-1;
 let compression=0,bend=0,grounding=0,whip=0;

 if(t<GRAB_END){
  const reach=S(t/GRAB_END);
  hips=lerp(p(800,500),p(835,568),reach);
  lean=.31*reach;
 }else if(t<LIFT_END){
  const lift=S((t-GRAB_END)/(LIFT_END-GRAB_END));
  hips=lerp(p(835,568),p(829,453),lift);
  grip=lerp(startGrip,p(1012,FLOOR-opponentHeight-34),lift);
  theta=mix(startAngle,DANGLE_ANGLE,lift);
  lean=mix(.31,.13,lift);
 }else if(t<=HOLD_END){
  const beat=SLAM_TIMES.findIndex((hit,i)=>t<=hit+(i===3?FINAL_HOLD:IMPACT_HOLD));
  const side=beat%2?-1:1;
  const hit=SLAM_TIMES[beat];
  const endAngle=side===1?LANDING_ANGLE:-Math.PI-LANDING_ANGLE;
  const startAngle=beat===0?DANGLE_ANGLE:(side===1?-Math.PI-LANDING_ANGLE:LANDING_ANGLE);
  const start=beat===0?LIFT_END:SLAM_TIMES[beat-1]+IMPACT_HOLD;
  const swing=C((t-start)/(hit-start));
  const arc=Math.sin(Math.PI*swing);

  // The first strike snaps from a dangling ankle. After contact, one sweep
  // carries the opponent across the shoulders and directly into the next hit.
  const sweep=beat===0?swing*swing:S(swing);
  theta=mix(startAngle,endAngle,sweep);
  hips=beat===0?lerp(p(829,453),p(910,570),sweep):p(800+side*110*(2*sweep-1),570-140*arc);
  lean=beat===0?mix(.13,.8,sweep):side*(1.6*sweep-.8);
  grip=beat===0
   ?lerp(p(1012,FLOOR-opponentHeight-34),p(1080,liftY),sweep)
   :p(800+side*280*(2*sweep-1),liftY-130*arc);
  grounding=beat===0?sweep*sweep:Math.pow(Math.abs(2*swing-1),4);
  whip=side*arc;
  bend=side*Math.sin(Math.PI*swing)*.74;
  if(t>=hit){
   const hold=beat===3?FINAL_HOLD:IMPACT_HOLD;
   const recoil=Math.sin(C((t-hit)/hold)*Math.PI);
   impact=beat;
   compression=.12*recoil;
   bend=-side*.50*recoil;
   hips.y+=22*recoil;
  }
 }else{
  const settle=S((t-HOLD_END)/(SLAM_ACTION_END-HOLD_END));
  theta=mix(-Math.PI-LANDING_ANGLE,-Math.PI,settle);
  grip=p(mix(520,514,settle),liftY);
  hips=lerp(p(690,570),p(800,500),settle);
  lean=mix(-.8,0,settle);
  grounding=1;
 }
 const height=opponentHeight*(1-compression),width=height*opponentWidthRatio;
 const segments=victimSegments(height,width,bend,ankle);
 const amount=S((t-GRAB_END)/.32)*(1-S((t-HOLD_END)/(SLAM_ACTION_END-HOLD_END)));
 const shock=SLAM_TIMES.reduce((sum,hit)=>{const age=t-hit;return age<0?sum:sum+Math.exp(-age*8)*Math.sin(age*29);},0);
 const ragdoll=createSlamRagdoll(height,width,{time:t,amount,bend,whip,shock,ankle});
 let bounds=victimBounds(segments,theta,opponentOutline,ragdoll);
 if(bounds.maxY-bounds.minY>610){ragdoll.fit=610/(bounds.maxY-bounds.minY);bounds=victimBounds(segments,theta,opponentOutline,ragdoll);}
 grip={...grip,x:Math.max(24-bounds.minX,Math.min(1576-bounds.maxX,grip.x))};
 const groundY=FLOOR-bounds.maxY;
 const safeY=Math.min(groundY,Math.max(80-bounds.minY,grip.y));
 grip={...grip,y:mix(safeY,groundY,grounding)};
 const victimCenter=p(grip.x+(bounds.minX+bounds.maxX)/2,grip.y+(bounds.minY+bounds.maxY)/2);
 const impactPoint=p(grip.x+bounds.contact.x,FLOOR);
 // Hip drive leads a visible torso pivot; all four shoulder sockets follow it.
 const turn=Math.sin(lean)*.9,torsoScale=1-Math.abs(turn)*.20;
 const socket=(x,y)=>{const tx=x*torsoScale+y*turn*.18,ty=y-x*turn*.08;return p(hips.x+tx*Math.cos(lean)-ty*Math.sin(lean),hips.y+tx*Math.sin(lean)+ty*Math.cos(lean));};
 const shoulders=[socket(-78,-135),socket(78,-135),socket(-72,-62),socket(72,-62)],locked=t>=GRAB_END&&t<=HOLD_END;
 const hands=shoulders.map((root,i)=>{
  if(i===1){if(t<GRAB_END)return lerp(p(root.x+35,root.y+75),grip,S(t/GRAB_END));if(t<=HOLD_END)return grip;return lerp(grip,p(hips.x+95,hips.y-75),S((t-HOLD_END)/.4));}
  const side=i%2?1:-1;return p(hips.x+side*(130+Math.abs(lean)*90),hips.y-(i<2?105:5)-lean*side*140);
 });
 if(t>7.6){const brush=Math.sin((t-7.6)*16)*13,q=S((t-7.6)/.35);hands.forEach((hand,i)=>{hands[i]=lerp(hand,p(800+(i%2?22:-22)+(i%2?-brush:brush),i<2?390:500),q);});}
 const arms=shoulders.map((root,i)=>{const d=Math.hypot(root.x-hands[i].x,root.y-hands[i].y);return {root,...twoBone(root,hands[i],Math.max(90,d*.56),Math.max(85,d*.5),i%2?-1:1)};});
 const legs=[p(675+turn*24,FLOOR),p(930+turn*24,FLOOR)].map((foot,i)=>{const root=socket(i?50:-50,42);return {root,...twoBone(root,foot,125,140,i?-1:1)};});
 return {t,theta,grip,hips,arms,legs,lean,turn,torsoScale,locked,impact,compression,opponentHeight:height,opponentWidth:width,segments,ragdoll,bounds,bend,victimCenter,impactPoint,stage:t<GRAB_END?'GRAB':t<LIFT_END?'LIFT':t<=HOLD_END?'FOUR SLAMS':t<7.6?'RELEASE':'DUST OFF',count:SLAM_TIMES.filter(end=>t>=end).length};
}
function sprite(ctx,image,a,b,width,extend=.08){const dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy);ctx.save();ctx.translate(a.x,a.y);ctx.rotate(Math.atan2(dy,dx)-Math.PI/2);ctx.drawImage(image,-width/2,-length*extend,width,length*(1+extend*2));ctx.restore();}
function drawArm(ctx,assets,arm){
 sprite(ctx,assets.upperArm,arm.root,arm.elbow,68,.14);sprite(ctx,assets.forearm,arm.elbow,arm.hand,59,.12);
 ctx.save();ctx.translate(arm.hand.x,arm.hand.y);ctx.rotate(Math.atan2(arm.hand.y-arm.elbow.y,arm.hand.x-arm.elbow.x)-Math.PI/2);ctx.drawImage(assets.hand,-24,-28,48,50);ctx.restore();
}
function body(ctx,assets,pose){
 // Rear limbs, torso over the sockets, then the foreground gripping arm.
 for(const i of [0,2])drawArm(ctx,assets,pose.arms[i]);
 for(const leg of pose.legs){sprite(ctx,assets.thigh,leg.root,leg.elbow,100,.14);sprite(ctx,assets.shin,leg.elbow,leg.hand,94,.09);}
 ctx.save();ctx.translate(pose.hips.x,pose.hips.y);ctx.rotate(pose.lean);ctx.transform(pose.torsoScale,-pose.turn*.08,pose.turn*.18,1,0,0);ctx.drawImage(assets.torso,-118,-285,236,377);ctx.restore();
 drawArm(ctx,assets,pose.arms[3]);
}
function opponent(ctx,image,pose,alpha=1,trail=0){
 ctx.save();ctx.globalAlpha=alpha;ctx.translate(pose.grip.x,pose.grip.y);ctx.rotate(pose.theta+Math.PI/2+trail);
 drawSlamRagdoll(ctx,image,pose.ragdoll);
 ctx.restore();
}
function dust(ctx,pose,options){
 for(const hit of SLAM_TIMES){
  const age=pose.t-hit;
  if(age<0||age>.48)continue;
  const landing=slamPose(hit,options);
  const center=landing.victimCenter.x;
  const fade=1-age/.48;
  ctx.save();
  ctx.globalAlpha=fade*.45;
  ctx.fillStyle='#e9bc83';
  ctx.beginPath();
  ctx.ellipse(center,FLOOR+2,58+age*230,5+age*22,0,0,Math.PI*2);
  ctx.fill();
  for(let i=0;i<22;i++){
   const angle=i*2.399;
   const spread=42+age*(155+i%4*38);
   const height=Math.abs(Math.sin(angle))*Math.sin(age/.48*Math.PI)*56;
   ctx.globalAlpha=fade*(i%3===0?.8:.46);
   ctx.fillStyle=i%3===0?'#f5d4a0':'#ae8b67';
   ctx.beginPath();
   ctx.ellipse(center+Math.cos(angle)*spread,FLOOR-height,4+i%4*2,3+i%3,angle,0,Math.PI*2);
   ctx.fill();
  }
  ctx.restore();
 }
}
export function slamJolt(pose,reducedMotion=false){
 if(reducedMotion||pose.impact<0)return p(0,0);
 const age=pose.t-SLAM_TIMES[pose.impact],kick=1-C(age/.17);
 return p(Math.sin(age*79)*kick*10,Math.sin(age*53)*kick*3);
}
export function drawKardozoGrip(ctx,assets,pose,{width=1600,height=900,reducedMotion=false}={}){
 ctx.clearRect(0,0,width,height);ctx.save();ctx.scale(width/1600,height/900);
 const jolt=slamJolt(pose,reducedMotion);ctx.translate(jolt.x,jolt.y);
 drawArm(ctx,assets,pose.arms[1]);ctx.restore();
}
export function drawKardozoSlam(ctx,assets,time,{width=1600,height=900,mirror=false,review=false,background=true,reducedMotion=false,drawVictim=true,drawGrip=true,...options}={}){
 const poseOptions={opponentOutline:assets.opponentOutline,...options},pose=slamPose(time,poseOptions);ctx.save();ctx.clearRect(0,0,width,height);ctx.scale(width/1600,height/900);
 if(background&&assets.background){ctx.drawImage(assets.background,0,0,1600,900);ctx.fillStyle='#08050840';ctx.fillRect(0,0,1600,900);}
 if(mirror){ctx.translate(1600,0);ctx.scale(-1,1);}
 const jolt=slamJolt(pose,reducedMotion);ctx.translate(jolt.x,jolt.y);
 ctx.fillStyle='#0006';ctx.beginPath();ctx.ellipse(805,FLOOR+5,150,20,0,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.ellipse(pose.victimCenter.x,FLOOR+5,80,12,0,0,Math.PI*2);ctx.fill();
 body(ctx,assets,pose);if(drawVictim)opponent(ctx,assets.opponent,pose);if(drawGrip)drawArm(ctx,assets,pose.arms[1]);dust(ctx,pose,poseOptions);ctx.restore();
 if(review){ctx.save();ctx.scale(width/1600,height/900);ctx.fillStyle='#050508dd';ctx.fillRect(0,0,1600,78);ctx.fillStyle='#f5d098';ctx.font='bold 27px sans-serif';ctx.fillText('KARDOZO / '+pose.stage,42,49);ctx.textAlign='right';ctx.fillText(pose.count+' / 4 IMPACTS',1558,49);ctx.restore();}
 return pose;
}
